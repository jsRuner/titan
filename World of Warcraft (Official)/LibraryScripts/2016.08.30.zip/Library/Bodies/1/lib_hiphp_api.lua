﻿--[[

]]--


--物品是否是unit施放的
function isObjectByUnit(unit,object)
	if unit and object then
		if ttGetObjectCreator(object)~=nil and ttGetObject(unit)==ttGetObject(GetObjectCreator(object)) then
			return true;
		end
	end
	return false;
end

--根据条件过滤
function filterObjs(conditionFunction, objs, returnAll)
	if objs==nil or #objs==0 then
		return nil;
	end
	local arr = {};
	for _,objId in ipairs(objs) do	
		if conditionFunction(objId) then
			if returnAll then
				table.insert(arr, objId);
			else
				return objId;
			end
		end
	end
	if returnAll then
		return arr;
	else
		return nil;
	end
end

function getObjs(conditionFunction, objs, returnAll)
	return filterObjs(conditionFunction, ttGetObjects({}) ,returnAll)
end

--释放技能
function castRunByName(name)
	-- body
	ChatFrame10.editBox:SetText("/cast "..name) 
	ChatEdit_SendText(ChatFrame10.editBox) 
	ChatFrame10.editBox:SetText("")
end

--选取目标
function targetRunByName(name)
	-- body
	ChatFrame10.editBox:SetText("/target "..name) 
	ChatEdit_SendText(ChatFrame10.editBox) 
	ChatFrame10.editBox:SetText("")
end


-----------------------------------------------------------------------------------
--商业模块
-----------------------------------------------------------------------------------
--判断是否打开了贩卖的窗口
function checkMerchant()
	local items = GetMerchantNumItems()
	if MerchantFrame:IsShown() and items > 0 then
		return true
	else
		return false
	end
end

--售卖列表
local shopping_list = {}
function add_Shopping_List(name,link,rarity,level,price,stack)
	local x
	local found = 0
	if price > 0 and #shopping_list > 1 then
		for x=1, #shopping_list, 1 do
			if shopping_list[x][1] == name then
				found = 1
				shopping_list[x][5] = shopping_list[x][5] + price
				shopping_list[x][6] = shopping_list[x][6] + stack
				shopping_list[x][7] = shopping_list[x][7] + 1
			end
		end
	end
	if price > 0 and #shopping_list == 0 or price > 0 and found == 0 then
		shopping_list[#shopping_list+1] = { name,link,rarity,level,price,stack,1 }
	end
end

local num = 0
--遍历包裹。符合售卖列表的，则可以售卖。需要判断当前商人是否可用。否则不执行
function findFishFromBag()
	-- body
	for bag = 0,NUM_BAG_SLOTS,1 do
		for slot = 1, GetContainerNumSlots(bag), 1 do
			local texture, itemCount, _, quality, _, _, itemLink, _ = GetContainerItemInfo(bag, slot);
			if texture ~= nil then
				local itemName, itemLink, itemRarity, itemLevel, _, _, _, _, _, _, itemSellPrice = GetItemInfo(itemLink);
				if itemName == '新月剑齿鱼清汤' then
					--添加到售卖列表
					add_Shopping_List(itemName,itemLink,quality,itemLevel,itemSellPrice,itemCount)
				end
				
				for i = 1, #shopping_list, 1 do
					if shopping_list[i][1] == itemName and shopping_list[i][3] == itemRarity then
						if not CursorHasItem() then
							-- Sell item
							UseContainerItem(bag,slot)
							print("出售"..itemLink)
							num = num + 1
						end
					end
				end
			end
		end
	end
end
--自动与指定Npc聊天。地址暂时无法存储。
function test()
	-- body
	-- local ttp= ttGetObjectPosition('player')
	-- print(ttp['X'])
	-- print(ttp['Y'])
	-- print(ttp['Z'])
	-- print(ttp['R'])
	-- _G.hiphpSellNpcP = ttp	
end

--[[
移动到阿什兰的克拉得军需官那。走的是直线。
--]]
local function getNpc()
	local objs = ttGetObjects({
		IncludedNamePattern="血卫士斩斧"
	});
	local npc = filterObjs(function(obj)
		return ttGetObjectName(obj)=="血卫士斩斧";
	end,objs,false)
	return npc;
end
function toNpc()
	-- body
	local npc = getNpc()
	if npc then
		InteractUnit(npc)
		SelectGossipOption(1)
		--卖东西的逻辑
		return;
	else
		t = GetDistance({['X']='5235.098',['Y']='-3977.462',['R']='11.317',['Z']='2.038'},ttGetObject('player'))
        if t > 10 then
        	ttClickToMove({['X']='5235.098',['Y']='-3977.462',['R']='11.317',['Z']='2.038'})
            return;
        end
	end
    return;
end
-----------------------------------------------------------------------------------
--钓鱼模块
-----------------------------------------------------------------------------------
local function getBobber()
	local objs = ttGetObjects({
		--IncludedNamePattern="鱼漂"
	});
	local bobber = filterObjs(function(obj)
		return ttGetObjectName(obj)=="鱼漂" and isObjectByUnit("player", obj);
	end,objs,false)
	return bobber;
end

--测试.如果包满了，自动售卖。
function xxx()
	-- body
end

--钓鱼之前的检查工作。鱼饵。
local function goFishBefore()
	-- body
	baitTable={"超级鱼虫","水下诱鱼器","锐利的鱼钩","明亮的小珠"}
	for _,v in ipairs(baitTable) do
		
		if GetItemCount(v)>0 and not GetWeaponEnchantInfo(v) then
			castRunByName(v);
			return;
		end
	end

end


local GotoFish = 0
function goFish()
	ttResetAfkTimer();
	goFishBefore()
	local bobber = getBobber()
	if bobber then
		if ttIsBobbing(bobber) then
			InteractUnit(bobber)
			return
		end
	else
        if GotoFish < GetTime() then
            CastSpellByName(tostring(select(1,GetSpellInfo(131474))))
            GotoFish = GetTime()+0.3
            return;
        end
	end
    return;
end

--杀鱼模块。寻找指定的鱼。存在则执行杀鱼逻辑
function killFish()
	-- body
	local baitTable={"巨型新月剑齿鱼","新月剑齿鱼","巨型海蝎子","海蝎子"}
	for _,v in ipairs(baitTable) do
		
		if GetItemCount(v)>=5  then
			castRunByName(v);
			return;
		end
	end
end

-----------------------------------------------------------------------------------
--战斗模块
-----------------------------------------------------------------------------------
local function getPlayer()
	local objs = ttGetObjects({
		IncludedTypes={"Player"}
	});
	local player = nil
	if objs ~=nil and #objs>1 then
		local randomIndex = math.random(1,#objs+1) 
		player = objs[randomIndex]
	end
	return player
end

--靠近目标
function toPlayer()
	-- body
	local player = getPlayer()
	if nil then
	else
		t = GetDistance({['X']='5235.098',['Y']='-3977.462',['R']='11.317',['Z']='2.038'},ttGetObject('player'))
        if t > 10 then
        	ttClickToMove({['X']='5235.098',['Y']='-3977.462',['R']='11.317',['Z']='2.038'})
            return;
        end
	end
    return;
end


local randomTreatment = 0  --控制间隔
local tlast = nil --上一个对象
local tchange = 0 --转换目标的条件。每一次操作，都会执行5+1间隔。6秒就执行一次切换。。
--寻找身边的目标，判断距离，够近就刷血，不够就移动。随机选择然后 释放治疗技能。
--如果处于移动状态。则需要做个标记。不要重新获取对象。
--如果尝试5秒后，无法治疗，则重新获取目标
function goRandomTreatment()
	-- body
	local pob = nil
	if randomTreatment < GetTime() then
		if tlast == nil then
			pob = getPlayer()
			tchange = 0 
		else
			pob = tlast
			tchange = tchange +1
		end

		if pob ~=nil then
			--判断是否有障碍物。
			-- isIntersected = CheckIntersection(ttGetObjectPosition(pob), ttGetObjectPosition("player"),'BoundingModel')
			-- if isIntersected then
			-- 	print('有障碍物')
			-- 	return
			-- end

			pobName = ttGetObjectName(pob)
			print(pobName)
			targetRunByName(pobName)
			--判断距离
			t = GetDistance(pob,ttGetObject('player'))
			--过远则位移。移动5秒。然后就不管了

			if t > 20 and tchange<=6 then
				tlast = pob
				ttClickToMove(pob)
				randomTreatment = GetTime()+5 --确保间隔 5秒
				return
			end
			castRunByName("恢复");
			tlast = nil
		end
		randomTreatment = GetTime()+1  --确保间隔1秒
	end
end